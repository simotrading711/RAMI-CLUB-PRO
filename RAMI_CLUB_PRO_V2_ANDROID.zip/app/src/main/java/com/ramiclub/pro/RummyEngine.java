package com.ramiclub.pro;
import java.util.*;
public class RummyEngine {
 public final List<Card> stock=new ArrayList<>(),discard=new ArrayList<>(),hand=new ArrayList<>(); public final int handSize;
 public RummyEngine(int players,int size){handSize=size;for(int d=0;d<2;d++){for(String s:new String[]{"H","D","C","S"})for(int r=1;r<=13;r++)stock.add(new Card(s,r,false));stock.add(new Card("J",0,true));stock.add(new Card("J",0,true));}Collections.shuffle(stock);for(int p=0;p<players;p++)for(int i=0;i<size;i++){Card c=stock.remove(stock.size()-1);if(p==0)hand.add(c);}discard.add(stock.remove(stock.size()-1));}
 public Card drawStock(){if(stock.isEmpty()&&discard.size()>1){Card top=discard.remove(discard.size()-1);stock.addAll(discard);discard.clear();discard.add(top);Collections.shuffle(stock);}if(stock.isEmpty())return null;Card c=stock.remove(stock.size()-1);hand.add(c);return c;}
 public Card drawDiscard(){if(discard.isEmpty())return null;Card c=discard.remove(discard.size()-1);hand.add(c);return c;}
 public boolean toss(int i){if(i<0||i>=hand.size()||hand.size()<=handSize)return false;discard.add(hand.remove(i));return true;}
 public String top(){return discard.isEmpty()?"—":discard.get(discard.size()-1).label();}
}
