package com.ramiclub.pro;
public class Card {
 public final String suit; public final int rank; public final boolean joker;
 public Card(String s,int r,boolean j){suit=s;rank=r;joker=j;}
 public String label(){if(joker)return "JOKER";String r=rank==1?"A":rank==11?"J":rank==12?"Q":rank==13?"K":""+rank;String s=suit.equals("H")?"♥":suit.equals("D")?"♦":suit.equals("C")?"♣":"♠";return r+s;}
 public boolean red(){return suit.equals("H")||suit.equals("D");}
}
