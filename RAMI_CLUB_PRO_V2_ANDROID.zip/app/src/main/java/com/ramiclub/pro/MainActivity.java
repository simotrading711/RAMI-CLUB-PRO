package com.ramiclub.pro;
import android.app.*;import android.os.Bundle;import android.graphics.Color;import android.view.Gravity;import android.widget.*;
public class MainActivity extends Activity{
 LinearLayout root;RummyEngine game;int size=13,selected=-1;int gold=Color.rgb(220,180,75);
 public void onCreate(Bundle b){super.onCreate(b);home();}
 TextView label(String s,int n){TextView t=new TextView(this);t.setText(s);t.setTextSize(n);t.setTextColor(-1);t.setGravity(Gravity.CENTER);t.setPadding(5,10,5,10);return t;}
 Button button(String s){Button b=new Button(this);b.setText(s);b.setTextColor(gold);b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(38,32,20)));return b;}
 void shell(String title){root=new LinearLayout(this);root.setOrientation(1);root.setPadding(10,16,10,10);root.setBackgroundColor(Color.rgb(9,9,9));setContentView(root);TextView h=label("RAMI CLUB PRO",25);h.setTextColor(gold);root.addView(h);root.addView(label(title,16));}
 void home(){shell("نسخة تجريبية محلية");Button a=button("Indian Rummy — 13 ورقة");root.addView(a);a.setOnClickListener(v->{size=13;start();});Button b=button("نسخة معدلة — 14 ورقة");root.addView(b);b.setOnClickListener(v->{size=14;start();});root.addView(label("تجربة توزيع الورق والسحب والرمي محلياً.",14));}
 void start(){game=new RummyEngine(2,size);selected=-1;table();}
 void table(){shell("الطاولة • "+size+" ورقة");root.addView(label("الكومة: "+game.stock.size()+" | المرمية: "+game.top(),14));LinearLayout actions=new LinearLayout(this);Button draw=button("اسحب");Button take=button("خذ المرمية");actions.addView(draw,new LinearLayout.LayoutParams(0,-2,1));actions.addView(take,new LinearLayout.LayoutParams(0,-2,1));root.addView(actions);
 draw.setOnClickListener(v->{if(game.hand.size()==size){game.drawStock();selected=-1;table();}else toast("ارمِ ورقة أولاً");});take.setOnClickListener(v->{if(game.hand.size()==size){game.drawDiscard();selected=-1;table();}else toast("ارمِ ورقة أولاً");});
 root.addView(label("يدك — اضغط لتحديد ورقة",13));for(int i=0;i<game.hand.size();i+=4){LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER);for(int j=i;j<Math.min(i+4,game.hand.size());j++){final int k=j;Card c=game.hand.get(j);Button cb=button(c.label());cb.setTextColor(c.red()?Color.RED:Color.WHITE);cb.setBackgroundTintList(android.content.res.ColorStateList.valueOf(j==selected?gold:Color.DKGRAY));row.addView(cb,new LinearLayout.LayoutParams(0,56,1));cb.setOnClickListener(v->{selected=k;table();});}root.addView(row);}
 Button toss=button("رمي الورقة المحددة");root.addView(toss);toss.setOnClickListener(v->{if(selected<0){toast("حدد ورقة");return;}if(game.toss(selected)){selected=-1;table();}else toast("لا يمكن الرمي");});Button back=button("الرئيسية");root.addView(back);back.setOnClickListener(v->home());}
 void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
}
