package com.ramiclub.pro;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class MainActivity extends Activity {
    private final int BG = Color.rgb(12, 12, 14);
    private final int PANEL = Color.rgb(27, 25, 22);
    private final int GOLD = Color.rgb(212, 175, 55);
    private final int CREAM = Color.rgb(245, 235, 205);
    private int handSize = 13;
    private int virtualCoins = 1000;
    private final List<String> hand = new ArrayList<>();
    private String drawnCard = null;
    private LinearLayout root;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        showHome();
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setGravity(Gravity.CENTER);
        t.setPadding(10, 10, 10, 10);
        return t;
    }

    private Button button(String value, Runnable action) {
        Button b = new Button(this);
        b.setText(value); b.setTextColor(Color.BLACK);
        b.setAllCaps(false);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(GOLD));
        b.setOnClickListener(v -> action.run());
        return b;
    }

    private void base(String title) {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(18, 22, 18, 18);
        root.setBackgroundColor(BG);
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.addView(root);
        setContentView(scroll);
        root.addView(text(title, 29, GOLD, true));
    }

    private void showHome() {
        base("RAMI CLUB PRO");
        root.addView(text("لعبة الرامي • 13 و14 ورقة", 17, CREAM, true));
        root.addView(text("رصيد تجريبي: " + virtualCoins + " نقطة", 16, GOLD, true));
        root.addView(text("اختر نمط اللعب", 19, CREAM, true));
        root.addView(button("رامي 13 ورقة", () -> startGame(13)));
        root.addView(button("رامي 14 ورقة", () -> startGame(14)));
        root.addView(text("غرف اللعب", 20, GOLD, true));
        root.addView(button("غرفة تدريب محلية", () -> startGame(13)));
        root.addView(button("البطولات (قريباً)", () -> message("سيتم إضافة البطولات بعد تجهيز الخادم.")));
        root.addView(button("المحفظة التجريبية", this::showWallet));
        root.addView(button("الملف الشخصي", () -> message("الحسابات وتسجيل الدخول ستضاف عند ربط الخادم.")));
        root.addView(text("نسخة أولية: اللعب محلي وبنقاط افتراضية فقط. لا توجد إيداعات أو سحوبات أو رهانات مالية.", 12, CREAM, false));
    }

    private void showWallet() {
        base("المحفظة");
        root.addView(text("رصيدك التجريبي", 18, CREAM, true));
        root.addView(text(virtualCoins + " نقطة", 30, GOLD, true));
        root.addView(text("هذه نقاط افتراضية لا تمثل أموالاً ولا يمكن شراؤها أو سحبها.", 14, CREAM, false));
        root.addView(button("رجوع", this::showHome));
    }

    private void startGame(int size) {
        handSize = size;
        hand.clear();
        drawnCard = null;
        List<String> deck = makeDeck();
        Collections.shuffle(deck);
        for (int i = 0; i < size; i++) hand.add(deck.remove(0));
        drawnCard = deck.remove(0);
        showTable();
    }

    private List<String> makeDeck() {
        List<String> d = new ArrayList<>();
        String[] suits = {"♥", "♦", "♣", "♠"};
        String[] ranks = {"A","2","3","4","5","6","7","8","9","10","J","Q","K"};
        for (int pack=0; pack<2; pack++)
            for (String s : suits) for (String r : ranks) d.add(r+s);
        return d;
    }

    private void showTable() {
        base("RAMI CLUB • طاولة اللعب");
        root.addView(text("نمط " + handSize + " ورقة", 17, GOLD, true));
        root.addView(text("الخصوم • لاعب 2     لاعب 3     لاعب 4", 13, CREAM, false));
        root.addView(text("منطقة اللعب", 18, GOLD, true));
        TextView pile = text("كومة السحب\n🂠", 24, CREAM, true);
        pile.setBackgroundColor(PANEL);
        root.addView(pile);
        root.addView(text("الورقة المسحوبة: " + (drawnCard == null ? "لم تسحب بعد" : drawnCard), 18, GOLD, true));
        root.addView(text("أوراقك", 18, CREAM, true));
        LinearLayout cards = new LinearLayout(this);
        cards.setOrientation(LinearLayout.HORIZONTAL);
        cards.setGravity(Gravity.CENTER);
        cards.setBackgroundColor(PANEL);
        for (String c : hand) {
            TextView card = text(c, 14, (c.contains("♥") || c.contains("♦")) ? Color.RED : Color.WHITE, true);
            card.setBackgroundColor(Color.rgb(238, 231, 210));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, 66, 1);
            lp.setMargins(2, 2, 2, 2);
            cards.addView(card, lp);
        }
        root.addView(cards);
        root.addView(button("سحب ورقة تجريبية", () -> {
            if (drawnCard != null) {
                hand.add(drawnCard);
                drawnCard = makeDeck().get((int)(Math.random()*52));
                showTable();
            }
        }));
        root.addView(button("إنهاء الدور (تجريبي)", () -> {
            if (!hand.isEmpty()) hand.remove(hand.size()-1);
            showTable();
        }));
        root.addView(button("العودة للرئيسية", this::showHome));
        root.addView(text("هذه طاولة تجريبية محلية وليست مباراة متعددة اللاعبين بعد.", 12, CREAM, false));
    }

    private void message(String msg) {
        new android.app.AlertDialog.Builder(this).setMessage(msg)
            .setPositiveButton("حسناً", (d,w) -> {}).show();
    }
}
